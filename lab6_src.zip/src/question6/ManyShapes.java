package question6;

import java.util.ArrayList;

public class ManyShapes {

	private ArrayList<Shape> allShapes;

	public ManyShapes() {
		this.allShapes = new ArrayList<Shape>();
	}// the ManyShapes constructor you need to create a new ArrayList object
		// and store it in the instance variable allShapes

	public void addShape(Shape s) {

		allShapes.add(s);
	}// add a new object o to the arraylist

	public void listAllShapes() {
		for (int i = 0; i < allShapes.size(); i++) {
			if (allShapes.get(i) instanceof Circle) {
				System.out.printf("Circle has area %.1f\n", allShapes.get(i).area());
			}
			if (allShapes.get(i) instanceof Dot) {
				System.out.printf("Dot has area %.1f\n", allShapes.get(i).area());
			}
			if (allShapes.get(i) instanceof Rectangle) {
				if (allShapes.get(i) instanceof Square) {
					System.out.printf("Square has area %.1f\n", allShapes.get(i).area());
				} else
					System.out.printf("Rectanglehas has area %.1f\n", allShapes.get(i).area());

			}

		}
	}

// prints on the screen the area of each shape in the arraylist, one by one, using a loop.

	public static void testManyShapes() {
		ManyShapes m = new ManyShapes();
		m.addShape(new Circle(1.2, 3.4, 4.0));
		m.addShape(new Dot(1.2, 3.4));
		m.addShape(new Rectangle(1.2, 3.4, 4.0, 5.0));
		m.addShape(new Shape(1.2, 3.4));
		m.addShape(new Square(1.2, 3.4, 5.0));
		m.listAllShapes();

	}
}
