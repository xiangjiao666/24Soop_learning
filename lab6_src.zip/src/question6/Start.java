package question6;

public class Start {
	public static void main(String[] args) {
		Shape.testShape();
		Circle.testCircle();
		Dot.testDot();
		Rectangle.testRectangle();
		Square.testSquare();
		ManyShapes.testManyShapes();
	}
}
