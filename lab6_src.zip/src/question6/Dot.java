package question6;

public class Dot extends Shape {

	/* derives from the Shape */

	public Dot(double x, double y) {
		super(x, y);
	}

	public double area() {
		return 0;
	}

	public static void testDot() {
		Dot d = new Dot(1.2, 3.4);
		System.out.println(d.getX() == 1.2);
		System.out.println(d.getY() == 3.4);
		System.out.println(d.area() == 0.0);
	}

}
