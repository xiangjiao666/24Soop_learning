package question2;

public class Shape {

	private double x;
	private double y;
	// instance variables store the position
	// of the central point of the shape.

	public Shape(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double area() {
		System.out.println("An unknown shape has an unknown area!");
		return -1.0;
	}// computes as result the area of the shape:
	/*
	 * so the area method just prints a message
	 * "An unknown shape has an unknown area!" and returns a meaningless result such
	 * as -1.0
	 */

	public static void testShape() {
		Shape s = new Shape(1.2, 3.4);
		System.out.println(s.getX() == 1.2);
		System.out.println(s.getY() == 3.4);
		System.out.println(s.area() == -1.0);
	}

}
