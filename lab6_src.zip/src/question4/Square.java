package question4;

public class Square extends Rectangle {

	public Square(double x, double y, double size) {
		super(x, y, size, size);
		/*
		 * he constructor for Square takes three arguments: the x and y positions of the
		 * center of the square, and the size of the square.
		 */
	}

	public static void testSquare() {
		Square s = new Square(1.2, 3.4, 5.0);
		System.out.println(s.getX() == 1.2);
		System.out.println(s.getY() == 3.4);
		System.out.println(s.area() == 25.0);
	}

}
/*
 * Does the Square class need its own area method? no!!!
 * 
 */