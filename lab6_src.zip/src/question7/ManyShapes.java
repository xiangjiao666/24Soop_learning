package question7;

import java.util.ArrayList;

public class ManyShapes {

	private ArrayList<Shape> allShapes;

	public ManyShapes() {
		this.allShapes = new ArrayList<Shape>();
	}// the ManyShapes constructor you need to create a new ArrayList object
		// and store it in the instance variable allShapes

	public void addShape(Shape s) {

		allShapes.add(s);
	}// add a new object o to the arraylist

	public void listAllShapes() {
		for (int i = 0; i < allShapes.size(); i++) {
			System.out.println(allShapes.get(i));
		} /*
			 * use System.out.println to directly print every element of the arraylist
			 * (System.out.println will then automatically
			 */
	}

// prints on the screen the area of each shape in the arraylist, one by one, using a loop.

	public static void testManyShapes() {
		ManyShapes m = new ManyShapes();
		m.addShape(new Circle(1.2, 3.4, 4.0));
		m.addShape(new Dot(1.2, 3.4));
		m.addShape(new Rectangle(1.2, 3.4, 4.0, 5.0));
		m.addShape(new Shape(1.2, 3.4));
		m.addShape(new Square(1.2, 3.4, 5.0));
		m.listAllShapes();
	}

}
