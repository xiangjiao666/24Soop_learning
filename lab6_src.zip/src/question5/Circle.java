package question5;

public class Circle extends Shape {

	// derives from the Shape
	private double radius;

	public Circle(double x, double y, double radius) {
		super(x, y);
		this.radius = radius;
	}

	public double area() {
		return Math.PI * radius * radius;
	}// Use Math.PI to compute the area of a circle.

	public static void testCircle() {
		Circle c = new Circle(1.2, 3.4, 4.0);
		System.out.println(c.getX() == 1.2);
		System.out.println(c.getY() == 3.4);
		System.out.println(c.area() == Math.PI * 16.0);
	}
}
